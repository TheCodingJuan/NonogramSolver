# Solucionador de Nonogramas
## Proyecto de Análisis de Algoritmos

Forma de ejecución:
``` python3 NonogramSolver.py filename ``

Se proveen algunas entradas aquí listadas y mostrando si el programa las soluciona:
- input_15x25.txt, SI
- input_35x30.txt, NO
- input_F.txt, NO
- input_00.txt, SI
- input_15x30.txt, SI (se demora un poco)
- input_3x3.txt, SI
- input.txt, SI
- input_01.txt, SI
- input_16x30.txt, NO
- input_8x8.txt, SI
